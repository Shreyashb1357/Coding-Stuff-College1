import java.util.ArrayList;
import java.util.Collection;


record Item(String name, String brand){}

record Customer(String name, )