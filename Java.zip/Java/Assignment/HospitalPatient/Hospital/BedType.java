package Hospital;

public enum BedType{
    economy , premium , delux;
}