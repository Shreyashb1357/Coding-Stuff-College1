package Bank;

public interface Taxable
{
    public double getTax();
    
}